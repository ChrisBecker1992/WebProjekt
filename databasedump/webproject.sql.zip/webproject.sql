-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 02. Jul 2017 um 16:04
-- Server-Version: 10.1.21-MariaDB
-- PHP-Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `webproject`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `abroad`
--

CREATE TABLE `abroad` (
  `id` int(10) UNSIGNED NOT NULL,
  `userId` int(11) UNSIGNED NOT NULL,
  `topic` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT;

--
-- Daten für Tabelle `abroad`
--

INSERT INTO `abroad` (`id`, `userId`, `topic`) VALUES
(6, 9, 'sda'),
(7, 9, 'nono'),
(9, 9, '??');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `event`
--

CREATE TABLE `event` (
  `id` int(10) UNSIGNED NOT NULL,
  `userId` int(10) UNSIGNED NOT NULL,
  `topic` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT;

--
-- Daten für Tabelle `event`
--

INSERT INTO `event` (`id`, `userId`, `topic`) VALUES
(1, 9, 'ok'),
(2, 7, 'button hide/show test');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `habitation`
--

CREATE TABLE `habitation` (
  `id` int(10) NOT NULL,
  `userId` int(10) NOT NULL,
  `topic` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT;

--
-- Daten für Tabelle `habitation`
--

INSERT INTO `habitation` (`id`, `userId`, `topic`) VALUES
(1, 12, 'Brauche Zimmer in Wörgl'),
(2, 12, 'Brauche Zimmer noch ein in Wörgl'),
(21, 9, 'neu'),
(22, 9, 'hallo'),
(23, 9, 'eada'),
(24, 7, 'hello');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `help`
--

CREATE TABLE `help` (
  `id` int(10) NOT NULL,
  `userId` int(10) NOT NULL,
  `topic` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT;

--
-- Daten für Tabelle `help`
--

INSERT INTO `help` (`id`, `userId`, `topic`) VALUES
(1, 9, 'test'),
(2, 7, 'test123');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user`
--

CREATE TABLE `user` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) CHARACTER SET utf8 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `user`
--

INSERT INTO `user` (`id`, `name`, `password`) VALUES
(7, 'mendez12', '$2y$10$c9NSmVVyQJ0vKiXbGvprR.kQP60gR9NPTcIjQx0dL.T/RpK40UUwS'),
(8, 'tobi1234', '$2y$10$cs5dSx0nW7M.vt34.TH0hunhDdcwoWDx74I7ciVm3/5tJ//PVq1dS'),
(9, 'sandro123', '$2y$10$6ZWFzCXYk1yNLSg9k75TPe4Sg/15oe1UVYS1KtmNevVfWSUQ4npce'),
(10, 'sandro1532', '$2y$10$QUj9amSjZp3U1h1j8TMnbehdJA/upk/ZbBRm/3E/y36YcI5Jul8wm'),
(11, 'sandro1532643', '$2y$10$u5oMbceD0.V7matebnuEke7fo5jNUpqT1/JpRAAXMLYeOyzd4BwdG'),
(12, 'hans1234', '$2y$10$eHa7HifVAIwTl3BKximfQOFSP6.4PiOabQ0/QWkj5Pd1y75oKCM7G');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `abroad`
--
ALTER TABLE `abroad`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Indizes für die Tabelle `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Indizes für die Tabelle `habitation`
--
ALTER TABLE `habitation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Indizes für die Tabelle `help`
--
ALTER TABLE `help`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Indizes für die Tabelle `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `abroad`
--
ALTER TABLE `abroad`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT für Tabelle `event`
--
ALTER TABLE `event`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT für Tabelle `habitation`
--
ALTER TABLE `habitation`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT für Tabelle `help`
--
ALTER TABLE `help`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT für Tabelle `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `abroad`
--
ALTER TABLE `abroad`
  ADD CONSTRAINT `abroad_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
